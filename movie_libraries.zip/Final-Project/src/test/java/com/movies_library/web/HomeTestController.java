package com.movies_library.web;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class HomeTestController {
    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private HomeController homeController;

    @Test
    public void contexLoads() throws Exception {
        assertThat(homeController).isNotNull();
    }

    @Test
    @WithMockUser(username = "user", password = "user", roles = "USER")
    public void testIfHomeReturnsCorrectStatusCode() throws Exception {
        this.mockMvc.perform(get("/home").secure(true)).andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "user", password = "user", roles = "USER")
    public void testIfIndexReturnsCorrectStatusCodeWithUser() throws Exception {
        this.mockMvc.perform(get("/").secure(true)).andExpect(status().isForbidden());
    }

    @Test
    public void testIfIndexReturnsCorrectStatusCode() throws Exception {
        this.mockMvc.perform(get("/").secure(true)).andExpect(status().isOk());
    }
}
