package com.movies_library.web;

import com.movies_library.models.entities.Actor;
import com.movies_library.repository.ActorRepository;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class ActorTestController {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ActorRepository actorRepository;


    private Long TEST_ACTOR_ID = 1L;
    private Long TEST_ACTOR1_ID = 2L;


    Actor actor = new Actor();
    Actor actor1 = new Actor();

    @Autowired
    private ActorController controller;

    @BeforeEach
    public void setup() {



        actor.setFirstName("Denzel");
        actor.setLastName("Washington");
        actorRepository.save(actor);
        TEST_ACTOR_ID = actor.getId();

        actor1.setFirstName("Christian");
        actor1.setLastName("Bale");
        actorRepository.save(actor1);
        TEST_ACTOR1_ID = actor1.getId();
    }

    @AfterEach
    public void tearDown() {
        this.actorRepository.delete(actor);
        this.actorRepository.delete(actor1);
    }

    @Test
    public void contextLoads() throws Exception {
        assertThat(controller).isNotNull();
    }

    @Test
    @WithMockUser(username = "peter", password = "peter", roles = "USER")
    public void testIfActorsReturnCorrectStatusCode() throws Exception {
        this.mockMvc.perform(get("/actors/all-actors").secure(true)).andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "peter", password = "peter", roles = "USER")
    public void testIfActorNotFoundReturnsCorrectCode() throws Exception {
        this.mockMvc.perform(get("/actor-details/555/").secure(true)).andExpect(status().isOk());
    }

}