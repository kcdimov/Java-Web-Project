package com.movies_library.web;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
public class UserTestController {
    @Autowired
    private MockMvc mockMvc;

    @Test
    @WithMockUser(username = "user", password = "user", roles = "USER")
    public void testIfLoginWithUserReturnCorrectStatusCode() throws Exception {
        this.mockMvc.perform(get("/login").secure(true)).andExpect(status().isForbidden());
    }

    @Test
    public void testIfLoginWithoutUserReturnCorrectStatusCode() throws Exception {
        this.mockMvc.perform(get("/login").secure(true)).andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "user", password = "user", roles = "USER")
    public void testIfRegisterWithUserReturnCorrectStatusCode() throws Exception {
        this.mockMvc.perform(get("/register").secure(true)).andExpect(status().isForbidden());
    }

    @Test
    public void testIfRegisterWithoutUserReturnCorrectStatusCode() throws Exception {
        this.mockMvc.perform(get("/register").secure(true)).andExpect(status().isOk());
    }

}
