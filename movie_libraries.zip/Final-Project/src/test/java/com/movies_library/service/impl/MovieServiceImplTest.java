package com.movies_library.service.impl;

import com.movies_library.models.entities.Genre;
import com.movies_library.models.entities.Movie;
import com.movies_library.repository.MovieRepository;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class MovieServiceImplTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private MovieRepository movieRepository;


    @Test
    void addMovie() {
    }

    @Test
    void findMovieByTitle() {
        Movie movie = new Movie();
        movie.setTitle("Top Gun");
        List<Genre> genres = new ArrayList<>();
        movie.setGenres(genres);
        entityManager.persist(movie);
        entityManager.flush();

        Movie found = movieRepository.findByTitle(movie.getTitle());

        assertThat(found.getTitle())
                .isEqualTo(movie.getTitle());
    }

    @Test
    void getAllMovieTitles() {
    }

    @Test
    void getAllMovies() {

    }

    @Test
    void getAllMoviesByUser() {
    }

    @Test
    void findById() {
        Movie movie = new Movie();
        movie.setTitle("Top Gun");
        List<Genre> genres = new ArrayList<>();
        movie.setGenres(genres);
        entityManager.persist(movie);
        entityManager.flush();

        Movie found = movieRepository.findById(movie.getId()).orElse(null);

        assertThat(found.getId())
                .isEqualTo(movie.getId());
    }
}