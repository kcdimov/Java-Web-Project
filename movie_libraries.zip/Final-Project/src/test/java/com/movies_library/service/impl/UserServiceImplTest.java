package com.movies_library.service.impl;

import com.movies_library.models.entities.Authority;
import com.movies_library.models.entities.User;
import com.movies_library.repository.UserRepository;
import com.movies_library.services.impl.UserServiceImpl;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;


@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class UserServiceImplTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private UserRepository userRepository;

    @InjectMocks
    private UserServiceImpl userService;

    @Test
    void loadUserByUsername() {
    }

    @Test
    void register() {

    }

    @Test
    void findByUsername() {
        User peter = new User();
        peter.setUsername("peter");
        peter.setEmail("peter@abv.bg");
        peter.setPassword("peter");
        Authority authority = new Authority();
        authority.setName(new SimpleGrantedAuthority("ROlE_USER"));
        entityManager.persistAndFlush(authority);
        List<Authority> authorities = new ArrayList<>();
        authorities.add(authority);
        peter.setAuthorities(authorities);
        entityManager.persist(peter);
        entityManager.flush();

        User found = userRepository.findByUsername(peter.getUsername());

        assertThat(found.getUsername())
                .isEqualTo(peter.getUsername());
    }

    @Test
    void findByEmail() {
        User peter = new User();
        peter.setUsername("peter");
        peter.setEmail("peter@abv.bg");
        peter.setPassword("peter");
        entityManager.persist(peter);
        entityManager.flush();

        User found = userRepository.findByEmail(peter.getEmail());

        assertThat(found.getEmail())
                .isEqualTo(peter.getEmail());
    }

    @Test
    void findAll() {
    }
}