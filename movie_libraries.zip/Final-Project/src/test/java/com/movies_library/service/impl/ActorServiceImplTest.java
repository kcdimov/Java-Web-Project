package com.movies_library.service.impl;

import com.movies_library.models.entities.Actor;
import com.movies_library.repository.ActorRepository;
import com.movies_library.services.impl.ActorServiceImpl;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.BDDMockito.given;

@ExtendWith(MockitoExtension.class)
class ActorServiceImplTest {

    @Mock
    private ActorRepository actorRepository;

    @InjectMocks
    private ActorServiceImpl actorService;

    @Autowired
    private TestEntityManager entityManager;

    @Test
    void findByName() {
    }

    @Test
    void findById() {
    }

    @Test
    void addActor() {
    }

    @Test
    void getAllActorNames() {

    }

    @Test
    void getAllActors() {
        List<Actor> datas = new ArrayList<>();
        Actor actor = new Actor();
        actor.setFirstName("Tom");
        actor.setLastName("Cruise");


        Actor actor1 = new Actor();
        actor1.setFirstName("Tom");
        actor1.setLastName("Cruise");


        datas.add(actor);
        datas.add(actor1);

        given(actorRepository.findAll()).willReturn(datas);

        List<Actor> expexted = actorService.getAllActors();

        Assert.assertEquals(expexted, datas);

    }
}