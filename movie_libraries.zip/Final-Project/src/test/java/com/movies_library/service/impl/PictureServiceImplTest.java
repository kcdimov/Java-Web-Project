package com.movies_library.service.impl;

import com.movies_library.models.entities.Actor;
import com.movies_library.models.entities.Movie;
import com.movies_library.models.entities.Picture;
import com.movies_library.repository.PictureRepository;
import com.movies_library.services.PictureService;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
class PictureServiceImplTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private PictureRepository pictureRepository;

    @MockBean
    private PictureService pictureService;

    @Test
    void addPicture() {
    }

    @Test
    void findPictureByActorId() {
        Actor actor = new Actor();
        actor.setFirstName("Russel");
        actor.setLastName("Crow");
        Picture picture = new Picture();
        picture.setUrl("url");
        picture.setActor(actor);
        List<Picture> pictures = new ArrayList<>();
        pictures.add(picture);
        actor.setPictures(pictures);
        entityManager.persist(actor);
        entityManager.flush();

        List<Picture> found = pictureRepository.findAllByActor_Id(actor.getId());

        assertThat(found.equals(pictures));
    }

    @Test
    void findPictureByMovieId() {
        Movie movie = new Movie();
        movie.setTitle("Gladiator");
        movie.setPlot("movie");
        Picture picture = new Picture();
        picture.setUrl("url");
        picture.setMovie(movie);
        List<Picture> pictures = new ArrayList<>();
        pictures.add(picture);
        movie.setPictures(pictures);
        entityManager.persist(movie);
        entityManager.flush();

        List<Picture> found = pictureRepository.findAllByMovie_Id((movie.getId()));

        assertThat(found.equals(pictures));
    }

    @Test
    void getRandomMoviePicture() {
    }

    @Test
    void findPictureByPictureId() {
        Actor actor = new Actor();
        actor.setFirstName("Russel");
        actor.setLastName("Crow");

        actor.setId(1L);
        Picture picture = new Picture();
        picture.setUrl("url");
        picture.setActor(actor);
        List<Picture> pictures = new ArrayList<>();
        pictures.add(picture);
        actor.setPictures(pictures);

        List<Picture> pictureList = this.pictureService.findPictureByActorId(actor.getId());

        assertThat(pictureList.equals(pictures));

    }
}