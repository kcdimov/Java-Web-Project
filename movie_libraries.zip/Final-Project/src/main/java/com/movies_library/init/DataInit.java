package com.movies_library.init;

import com.movies_library.models.entities.Authority;
import com.movies_library.models.entities.User;
import com.movies_library.repository.AuthorityRepository;
import com.movies_library.repository.UserRepository;
import com.movies_library.services.UserService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataInit implements CommandLineRunner {
    private final UserRepository userRepository;
    private final AuthorityRepository authorityRepository;
    private final UserService userService;
    private final PasswordEncoder passwordEncoder;

    public DataInit(UserRepository userRepository,
                    AuthorityRepository authorityRepository, UserService userService, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.authorityRepository = authorityRepository;
        this.userService = userService;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) throws Exception {
        if (userRepository.count() == 0) {
            User admin = new User();
            admin.setUsername("admin");
            admin.setPassword(passwordEncoder.encode("123"));
            admin.setEmail("admin@movie-library.com"); //TODO to hide email and password

            Authority authority = new Authority();
            authority.setName(new SimpleGrantedAuthority("ROlE_ADMIN"));
            List<User> admins = authority.getUsers();
            authorityRepository.saveAndFlush(authority);
            admins.add(admin);


            Authority authorityUser = new Authority();
            authorityUser.setName(new SimpleGrantedAuthority("ROlE_USER"));
            List<User> users = authorityUser.getUsers();
            authorityRepository.saveAndFlush(authorityUser);
            users.add(admin);

            List<Authority> authorities = new ArrayList<>();
            authorities.add(authority);
            authorities.add(authorityUser);
            admin.setAuthorities(authorities);
            userRepository.saveAndFlush(admin);
        }

    }
}
