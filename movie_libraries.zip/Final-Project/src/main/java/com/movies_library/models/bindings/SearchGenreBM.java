package com.movies_library.models.bindings;

public class SearchGenreBM {
    private String genre;

    public SearchGenreBM() {
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
}
