package com.movies_library.models.bindings;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

public class PictureAddBM {
    private String url;
    private String actorFirstName;
    private String actorLastName;
    private String movie;

    public PictureAddBM() {
    }

    @NotBlank(message = "Please enter picture's url")
    @Min(value = 1, message = "Please enter picture's url")
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMovie() {
        return movie;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }

    public String getActorFirstName() {
        return actorFirstName;
    }

    public void setActorFirstName(String actorFirstName) {
        this.actorFirstName = actorFirstName;
    }

    public String getActorLastName() {
        return actorLastName;
    }

    public void setActorLastName(String actorLastName) {
        this.actorLastName = actorLastName;
    }
}
