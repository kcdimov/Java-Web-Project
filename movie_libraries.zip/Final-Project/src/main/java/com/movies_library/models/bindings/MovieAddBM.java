package com.movies_library.models.bindings;

import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;

public class MovieAddBM {

    private String title;
    private String plot;
    private String genre;
    private String subgenre;
    private String actorInLeadingRoleFirstName;
    private String actorInLeadingRoleLastName;
    private String actorInSupportingRoleFirstName;
    private String actorInSupportingRoleLastName;
    private String directorFirstName;
    private String directorLastName;

    //TODO add music composer and validation of actor and directors

    public MovieAddBM() {
    }

    @NotBlank(message = "Movie title cannot be empty")
    @Length(min = 2, message = "Movie title must be minimum two characters")
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    @NotBlank(message = "Movie plot cannot be empty")
    @Length(min = 10, message = "Movie plot have to be minimum 10 characters")
    public String getPlot() {
        return plot;
    }

    public void setPlot(String plot) {
        this.plot = plot;
    }

    @NotBlank(message = "Genre cannot be empty")
    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getSubgenre() {
        return subgenre;
    }

    public void setSubgenre(String subgenre) {
        this.subgenre = subgenre;
    }

    @NotBlank(message = "Please enter actor first name")
    public String getActorInLeadingRoleFirstName() {
        return actorInLeadingRoleFirstName;
    }

    public void setActorInLeadingRoleFirstName(String actorInLeadingRoleFirstName) {
        this.actorInLeadingRoleFirstName = actorInLeadingRoleFirstName;
    }


    @NotBlank(message = "Please enter actor first name")
    public String getActorInSupportingRoleFirstName() {
        return actorInSupportingRoleFirstName;
    }

    public void setActorInSupportingRoleFirstName(String actorInSupportingRoleFirstName) {
        this.actorInSupportingRoleFirstName = actorInSupportingRoleFirstName;
    }
    @NotBlank(message = "Please enter actor last name")
    public String getActorInLeadingRoleLastName() {
        return actorInLeadingRoleLastName;
    }

    public void setActorInLeadingRoleLastName(String actorInLeadingRoleLastName) {
        this.actorInLeadingRoleLastName = actorInLeadingRoleLastName;
    }


    @NotBlank(message = "Please enter actor last name")
    public String getActorInSupportingRoleLastName() {
        return actorInSupportingRoleLastName;
    }

    public void setActorInSupportingRoleLastName(String actorInSupportingRoleLastName) {
        this.actorInSupportingRoleLastName = actorInSupportingRoleLastName;
    }


    @NotBlank(message = "Please enter director first name")
    public String getDirectorFirstName() {
        return directorFirstName;
    }

    public void setDirectorFirstName(String directorFirstName) {
        this.directorFirstName = directorFirstName;
    }


    @NotBlank(message = "Please enter actor last name")
    public String getDirectorLastName() {
        return directorLastName;
    }

    public void setDirectorLastName(String directorLastName) {
        this.directorLastName = directorLastName;
    }
}
