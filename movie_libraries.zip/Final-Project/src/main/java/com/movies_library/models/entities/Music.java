package com.movies_library.models.entities;

import org.hibernate.validator.constraints.Length;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "music")
public class Music extends BaseEntity{
    private String composerName;
    private Movie movie;
    //TODO eventually soundtrack of songs


    public Music() {
    }

    @Column(name = "composer_name")
    @Length(min = 5)
    @NotBlank
    public String getComposerName() {
        return composerName;
    }

    public void setComposerName(String composerName) {
        this.composerName = composerName;
    }

    @OneToOne
    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }
}
