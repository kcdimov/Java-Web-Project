package com.movies_library.models.bindings;

import lombok.experimental.ExtensionMethod;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;

public class UserRegisterBM {
    private String username;
    private String password;
    private String confirmPassword;
    private String email;

    public UserRegisterBM() {
    }

    @NotBlank
    @Length(min = 5,max = 15, message = "Username must minimum 5 and maximum 15 characters!")
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @NotBlank
    @Length(min = 3, message = "Password must be minimum 3 characters!")
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @NotBlank
    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    @NotBlank
    @Email(message = "Please, enter valid email!")
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
