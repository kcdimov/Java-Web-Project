package com.movies_library.models.servces;

import com.movies_library.models.entities.Movie;

import javax.validation.constraints.NotNull;
import java.util.List;

public class DirectorServiceModel {

    private String firstName;
    private String lastName;
    //TODO whether to add list of movies
   // private List<Movie> movies;


    public DirectorServiceModel() {
    }

    @NotNull
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @NotNull
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
