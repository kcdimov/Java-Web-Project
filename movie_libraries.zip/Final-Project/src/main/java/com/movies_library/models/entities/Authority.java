package com.movies_library.models.entities;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "authorities")
public class Authority extends BaseEntity{
    private SimpleGrantedAuthority name;
    private List<User> users = new ArrayList<>();

    public Authority() {
    }

    @Column
    @NotNull
    public SimpleGrantedAuthority getName() {
        return name;
    }

    public void setName(SimpleGrantedAuthority name) {
        this.name = name;
    }

    @ManyToMany(mappedBy = "authorities", cascade = CascadeType.MERGE)
    public List<User> getUsers() {
        return users;
    }

    public void setUsers(List<User> users) {
        this.users = users;
    }
}
