package com.movies_library.models.servces;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

public class AuthorityServiceModel extends BaseEntityServiceModel {
    private SimpleGrantedAuthority name;
    private UserServiceModel user;

    public AuthorityServiceModel() {
    }

    @NotNull
    public SimpleGrantedAuthority getName() {
        return name;
    }

    public void setName(SimpleGrantedAuthority name) {
        this.name = name;
    }


    public UserServiceModel getUser() {
        return user;
    }

    public void setUser(UserServiceModel user) {
        this.user = user;
    }
}
