package com.movies_library.models.servces;

public enum GenreServiceModel {
    ANIMATION, ACTION, DRAMA, COMEDY, FAMILY, ROMANCE, MUSICAL,
    ADVENTURE, FANTASY, SCI_FI, CRIME, THRILLER, MYSTERY, HISTORY, WESTERN;
}
