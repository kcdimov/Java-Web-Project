package com.movies_library.models.bindings;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

public class MusicAddBM {
    private String composerName;
    private String movie;

    public MusicAddBM() {
    }

    @NotBlank(message = "Please enter composer name")
    @Min(value = 5, message = "Composer name have to be minimum 5 characters")
    public String getComposerName() {
        return composerName;
    }

    public void setComposerName(String composerName) {
        this.composerName = composerName;
    }

    @NotBlank(message = "Please enter movie title")
    public String getMovie() {
        return movie;
    }

    public void setMovie(String movie) {
        this.movie = movie;
    }
}
