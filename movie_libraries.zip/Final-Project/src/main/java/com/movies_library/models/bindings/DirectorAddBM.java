package com.movies_library.models.bindings;


import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

public class DirectorAddBM {
    private String firstName;
    private String lastName;
    private String movies;

    public DirectorAddBM() {
    }

    @NotBlank(message = "Please enter director first name")
    @Min(value = 3, message = "Director first name have to be minimum 3 characters")
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @NotBlank(message = "Please enter director last name")
    @Min(value = 3, message = "Director last name have to be minimum 3 characters")
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @NotBlank(message = "Please enter movie title")
    public String getMovies() {
        return movies;
    }

    public void setMovies(String movies) {
        this.movies = movies;
    }
}
