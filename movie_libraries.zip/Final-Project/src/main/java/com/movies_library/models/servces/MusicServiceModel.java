package com.movies_library.models.servces;

import com.movies_library.models.entities.Movie;
import lombok.NonNull;
import org.hibernate.validator.constraints.Length;

public class MusicServiceModel extends BaseEntityServiceModel{

    private String composerName;
    private Movie movie;

    public MusicServiceModel() {
    }

    public String getComposerName() {
        return composerName;
    }

    @NonNull
    @Length(min = 5)
    public void setComposerName(String composerName) {
        this.composerName = composerName;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }
}
