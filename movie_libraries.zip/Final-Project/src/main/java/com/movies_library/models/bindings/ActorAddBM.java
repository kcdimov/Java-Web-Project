package com.movies_library.models.bindings;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

public class ActorAddBM {
    private String firstName;
    private String lastName;

    public ActorAddBM() {
    }

    @NotBlank(message = "Actor first name cannot be empty")
    @Min(value = 3, message = "First name have to be minimum 3 characters")
    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @NotBlank(message = "Actor last name cannot be empty")
    @Min(value = 3, message = "Last name have to be minimum 3 characters")
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
}
