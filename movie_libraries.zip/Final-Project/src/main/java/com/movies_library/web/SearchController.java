package com.movies_library.web;

import com.movies_library.models.bindings.SearchGenreBM;
import com.movies_library.services.MovieService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
public class SearchController {

    private final MovieService movieService;

    public SearchController(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping("/search/search/{genre}")
    public String search(@PathVariable("genre")String genre, Model model) {

        if (!model.containsAttribute("searchGenreBM")) {
            model.addAttribute("searchGenreBM", new SearchGenreBM());
        }
        if (!genre.equals("genre")){model.addAttribute("movies", this.movieService.getAllMoviesByGenre(genre));}

        return "redirect:search";
    }

    @PostMapping("/search/{genre}")
    public String searchPost (@Valid @ModelAttribute("searchGenreBM") SearchGenreBM searchGenreBM,
                              BindingResult bindingResult, RedirectAttributes redirectAttributes) {


        if (bindingResult.hasErrors()) {

            redirectAttributes.addFlashAttribute("searchGenreBM", searchGenreBM);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.searchGenreBM",
                    bindingResult);

            return "redirect:search/genre";
        }

        return "redirect:search/" + searchGenreBM.getGenre();
    }
}
