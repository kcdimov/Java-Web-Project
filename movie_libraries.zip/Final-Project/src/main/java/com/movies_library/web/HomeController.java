package com.movies_library.web;

import com.movies_library.services.ActorService;
import com.movies_library.services.MovieService;
import com.movies_library.services.ReviewService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpSession;

@Controller
public class HomeController {

    private final MovieService movieService;
    private final ActorService actorService;
    private final ReviewService reviewService;

    //TODO add director and composer

    public HomeController(MovieService movieService, ActorService actorService, ReviewService reviewService) {
        this.movieService = movieService;
        this.actorService = actorService;
        this.reviewService = reviewService;
    }

    @GetMapping("/home")
    public String home(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipal = authentication.getName();

        model.addAttribute("movies", this.movieService.getAllMoviesByUser(currentPrincipal));
        //TODO change moviesAll with allMovies
        model.addAttribute("moviesAll", this.movieService.getAllMovies());
        model.addAttribute("reviews", this.reviewService.getAllReviewsByUsername(currentPrincipal));

        return "home";
    }

    @GetMapping("/")
    public String index(Model model, HttpSession httpSession) {
        model.addAttribute("movies", this.movieService.getAllMovies());
        model.addAttribute("actors", this.actorService.getAllActors());
        model.addAttribute("name", httpSession.getAttribute("name"));

        return "index";
    }
}
