package com.movies_library.web;

import com.movies_library.models.bindings.ReviewAddBM;
import com.movies_library.models.servces.ReviewServiceModel;
import com.movies_library.services.MovieService;
import com.movies_library.services.ReviewService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@RequestMapping("reviews")
public class ReviewController {

    private final ReviewService reviewService;
    private final ModelMapper modelMapper;
    private final MovieService movieService;

    public ReviewController(ReviewService reviewService, ModelMapper modelMapper, MovieService movieService) {
        this.reviewService = reviewService;
        this.modelMapper = modelMapper;
        this.movieService = movieService;
    }

    @GetMapping("/add-review")
    public String addReview (Model model) {
        model.addAttribute("movieTitles", this.movieService.getAllTitleOfMovies());
        if (!model.containsAttribute("reviewAddBM")) {
            model.addAttribute("reviewAddBM", new ReviewAddBM());
        }
        return "add-review";
    }

    @PostMapping("/add-review")
    public String addReviewPost (@Valid ReviewAddBM reviewAddBM, BindingResult bindingResult,
                                 RedirectAttributes redirectAttributes, Model model) {

        model.addAttribute("movieTitles", this.movieService.getAllTitleOfMovies());

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("reviewAddBM", reviewAddBM);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.reviewAddBM",
                    bindingResult);
        }

        ReviewServiceModel reviewServiceModel = this.modelMapper.map(reviewAddBM, ReviewServiceModel.class);
        this.reviewService.addReview(reviewServiceModel, reviewAddBM.getMovie());

        return "home";
    }
}
