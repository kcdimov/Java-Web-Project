package com.movies_library.web;

import com.movies_library.models.bindings.ActorAddBM;
import com.movies_library.models.servces.ActorServiceModel;
import com.movies_library.services.ActorService;
import com.movies_library.services.PictureService;
import org.modelmapper.ModelMapper;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.io.IOException;

@Controller
@RequestMapping("/actors")
public class ActorController {

    private final ActorService actorService;
    private final PictureService pictureService;
    private final ModelMapper modelMapper;

    public ActorController(ActorService actorService, PictureService pictureService, ModelMapper modelMapper) {
        this.actorService = actorService;
        this.pictureService = pictureService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/actor-details/{id}")
    public String actorDetails(@PathVariable long id, Model model) throws IOException {

        ActorServiceModel actor = actorService.findById(id);
        model.addAttribute("actor", actor);
        model.addAttribute("picture", this.pictureService.getRandomActorPicture(id));

        return "actor-details";
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @GetMapping("/add-actor")
    public String addActor(Model model) {
        if (!model.containsAttribute("actorAddBM")) {
        model.addAttribute("actorAddBM", new ActorAddBM());
         }
        return "add-actor";
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @PostMapping("/add-actor")
    public String addActorPost(@Valid ActorAddBM actorAddBM, BindingResult bindingResult,
                               RedirectAttributes redirectAttributes) {

        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("actorAddBM", actorAddBM);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.actorAddBM",
                    bindingResult);
            return "redirect:add-actor";
        }

        this.actorService.addActor(modelMapper.map(actorAddBM, ActorServiceModel.class));
        ActorServiceModel actor = this.actorService.findActorsByNames(actorAddBM.getFirstName(),
                actorAddBM.getLastName());
        redirectAttributes.addFlashAttribute("actor", actor);
        return "redirect: actor-details/" + actor.getId();
    }

    @GetMapping("/all-actors")
    public String getAllActors(Model model) {
        //TODO change actors to allActors
        model.addAttribute("actors", this.actorService.getAllActors());
        return "all-actors";
    }
}
