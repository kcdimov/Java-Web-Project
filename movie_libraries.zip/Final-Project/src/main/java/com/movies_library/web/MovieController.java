package com.movies_library.web;

import com.movies_library.models.bindings.MovieAddBM;
import com.movies_library.models.entities.Movie;
import com.movies_library.models.servces.DirectorServiceModel;
import com.movies_library.models.servces.MovieServiceModel;
import com.movies_library.services.ActorService;
import com.movies_library.services.DirectorService;
import com.movies_library.services.MovieService;
import com.movies_library.services.PictureService;
import org.modelmapper.ModelMapper;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@RequestMapping("/movies")
public class MovieController {

    private final ActorService actorService;
    private final PictureService pictureService;
    private final ModelMapper modelMapper;
    private final MovieService movieService;
    private final DirectorService directorService;

    public MovieController(ActorService actorService, PictureService pictureService,
                           ModelMapper modelMapper, MovieService movieService, DirectorService directorService) {
        this.actorService = actorService;
        this.pictureService = pictureService;
        this.modelMapper = modelMapper;
        this.movieService = movieService;
        this.directorService = directorService;
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @GetMapping("/add-movie")
    public String addMovie(Model model) {
        if (!model.containsAttribute("movieAddBM")) {
            model.addAttribute("movieAddBM", new MovieAddBM());
        }

        //TODO replace actorNames with all-actors-names
        model.addAttribute("actorNames", this.actorService.getAllActorsNames());
        return "add-movie";
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @PostMapping("/add-movie")
    public String addMoviePost(@Valid @ModelAttribute("movieAddBM") MovieAddBM movieAddBM, BindingResult bindingResult,
                               RedirectAttributes redirectAttributes, Model model) {
        if (bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("movieAddBM", movieAddBM);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.movieAddBM",
                    bindingResult);
            return "redirect: add-movie";
        }
        MovieServiceModel movieServiceModel = modelMapper.map(movieAddBM, MovieServiceModel.class);

        model.addAttribute("actorNames", this.actorService.getAllActorsNames());
        //TODO add director
//        model.addAttribute("directorNames", this.directorService.findDirectorsByNames(movieServiceModel.getDirector().getFirstName(),
//                movieServiceModel.getDirector().getLastName()));

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipal = authentication.getName();

        this.movieService.addMovie(movieServiceModel, movieAddBM, currentPrincipal);

        Movie titleMovie = this.movieService.findMovieByTitle(movieServiceModel.getTitle());
        redirectAttributes.addFlashAttribute("movie", titleMovie);

        return "redirect:movie-details/" + titleMovie.getId();
    }

    @GetMapping("/all-movies")
    public String allMovies(Model model) {
        model.addAttribute(this.movieService.getAllMovies());

        return "all-movies";
    }

    @GetMapping("/movie-details/{id}")
    public String movieDetails(@PathVariable long id, Model model) {

        MovieServiceModel movieId = this.movieService.findById(id);

        model.addAttribute("movie", movieId);
        model.addAttribute("picture", this.pictureService.findPictureByMovieId(id));


        return "movie-details";
    }
}
