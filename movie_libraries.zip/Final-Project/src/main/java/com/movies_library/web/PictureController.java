package com.movies_library.web;

import com.movies_library.models.bindings.PictureAddBM;
import com.movies_library.models.servces.PictureServiceModel;
import com.movies_library.services.ActorService;
import com.movies_library.services.MovieService;
import com.movies_library.services.PictureService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;

@Controller
@RequestMapping("/pictures")
public class PictureController {

    private final ActorService actorService;
    private final PictureService pictureService;
    private final ModelMapper modelMapper;
    private final MovieService movieService;

    public PictureController(ActorService actorService, PictureService pictureService,
                             ModelMapper modelMapper, MovieService movieService) {
        this.actorService = actorService;
        this.pictureService = pictureService;
        this.modelMapper = modelMapper;
        this.movieService = movieService;
    }

    @GetMapping("/add-picture")
    public String addPicture(Model model) {
        model.addAttribute("movieTitles", this.movieService.getAllTitleOfMovies());
        model.addAttribute("actorNames", this.actorService.getAllActorsNames());

        if (!model.containsAttribute("pictureAddBM")) {
            model.addAttribute("pictureAddBM", new PictureAddBM());
        }

        return "add-picture";
    }

    @PostMapping("/add-picture")
    public String addPicturesPost(@Valid PictureAddBM pictureAddBM, BindingResult bindingResult,
                                  RedirectAttributes redirectAttributes, Model model) {
        model.addAttribute("movieTitles", this.movieService.getAllTitleOfMovies());
        model.addAttribute("actorNames", this.actorService.getAllActorsNames());

        if (!bindingResult.hasErrors()) {
            redirectAttributes.addFlashAttribute("pictureAddBM", pictureAddBM);
            redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.pictureAddBM",
                    bindingResult);
            return "redirect: add-picture";
        }

        PictureServiceModel pictureServiceModel = this.modelMapper.map(pictureAddBM, PictureServiceModel.class);
        this.pictureService.addPicture(pictureServiceModel, pictureAddBM.getActorFirstName(),
                pictureAddBM.getActorLastName(), pictureAddBM.getMovie());
        return "home";

    }
}
