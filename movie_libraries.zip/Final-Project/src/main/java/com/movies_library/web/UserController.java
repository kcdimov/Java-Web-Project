package com.movies_library.web;

import com.movies_library.models.bindings.UserRegisterBM;
import com.movies_library.models.servces.UserServiceModel;
import com.movies_library.services.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
public class UserController {

    private final ModelMapper modelMapper;
    private final UserService userService;

    public UserController(ModelMapper modelMapper, UserService userService) {
        this.modelMapper = modelMapper;
        this.userService = userService;
    }

    @GetMapping("/login")
    public String login() {
        return "login";
    }

    @PostMapping("/login-error")
    public ModelAndView loginError(@ModelAttribute(UsernamePasswordAuthenticationFilter.SPRING_SECURITY_FORM_USERNAME_KEY)
                                               String username) {
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.addObject("error", "bad.credentials");
        modelAndView.addObject("username", username);
        modelAndView.setViewName("login");

        return modelAndView;

    }

    @GetMapping("/register")
    public String register(Model model) {

        if (!model.containsAttribute("userRegisterBM")) {
            model.addAttribute("userRegisterBM", new UserRegisterBM());
        }

        return "register";
    }

    @PostMapping("/register")
    public String registerUser(@Valid @ModelAttribute("userRegisterBM")  UserRegisterBM userRegisterBM, BindingResult bindingResult,
                                RedirectAttributes redirectAttributes) {

        try {
            this.userService.findByUsername(userRegisterBM.getUsername());
            bindingResult.rejectValue("username", "error.user", "Username already exists!");
        } catch (Exception e) {
        }

        try {
            this.userService.findByEmail(userRegisterBM.getEmail());
            bindingResult.rejectValue("email", "error.user", "Email is already in use!");
        } catch (Exception e) {
        }

//        if (userService.usernameExist(userRegisterBM.getUsername())) {
//            redirectAttributes.addFlashAttribute("registrationBindingModel", userRegisterBM);
//            redirectAttributes.addFlashAttribute("userExistsError", true);
//
//            return "redirect:/users/register";
//        }

        if (bindingResult.hasErrors() || !userRegisterBM.getPassword()
                .equals(userRegisterBM.getConfirmPassword())) {
            redirectAttributes.addFlashAttribute("userRegisterBM", userRegisterBM);
            redirectAttributes
                    .addFlashAttribute("org.springframework.validation.BindingResult.userRegisterBM",
                           bindingResult);

            return "register";
        }

        this.userService.register(this.modelMapper.map(userRegisterBM, UserServiceModel.class));


        return "redirect:login";
    }

    @RequestMapping(value = "/logout", method = RequestMethod.GET)
    public String logout(HttpServletRequest request, HttpServletResponse response, HttpSession httpSession) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null) {
            new SecurityContextLogoutHandler().logout(request, response, auth);
        }
        httpSession.invalidate();
        return "redirect:/login";
    }
}
