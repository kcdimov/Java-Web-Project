package com.movies_library.services;

import org.springframework.stereotype.Service;

public interface MusicService {
}
