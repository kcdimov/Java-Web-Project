package com.movies_library.services.impl;

import com.movies_library.services.MusicService;
import org.springframework.stereotype.Service;

@Service
public class MusicServiceImpl implements MusicService {
    //TODO
}
