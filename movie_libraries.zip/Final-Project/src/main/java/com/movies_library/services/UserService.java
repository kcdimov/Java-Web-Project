package com.movies_library.services;

import com.movies_library.models.entities.User;
import com.movies_library.models.servces.UserServiceModel;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface UserService extends UserDetailsService {
    UserServiceModel register(UserServiceModel user);
    UserServiceModel findByUsername(String username);
    UserServiceModel findByEmail(String email);

    List<User> findAll();

    //boolean usernameExist(String username);

}
