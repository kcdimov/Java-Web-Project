package com.movies_library.services;

public interface EmailService {
    void sendMessage();
}
