package com.movies_library.services;

import com.movies_library.models.entities.Actor;
import com.movies_library.models.servces.ActorServiceModel;

import java.util.List;

public interface ActorService {
    ActorServiceModel findActorsByNames(String firstName, String lastName);
    ActorServiceModel findById(Long id);
    ActorServiceModel addActor(ActorServiceModel map);
    List<String> getAllActorsNames();
    List<Actor> getAllActors();

}
