package com.movies_library.services;

import com.movies_library.models.entities.Movie;
import com.movies_library.models.entities.Picture;
import com.movies_library.models.servces.PictureServiceModel;

import java.io.IOException;
import java.util.List;

public interface PictureService {

    PictureServiceModel addPicture(PictureServiceModel pictureServiceModel, String actorFirstName, String actorLastName,
                                   String movie);

    List<Picture> findPictureByActorId(Long id);
    List<Picture> findPictureByMovieId(Long id);

    String getRandomActorPicture(Long id) throws IOException;
    String getRandomPictureOfMovie(Long id);
}
