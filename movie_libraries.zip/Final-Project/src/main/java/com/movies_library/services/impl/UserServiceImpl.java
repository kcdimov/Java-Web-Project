package com.movies_library.services.impl;

import com.movies_library.models.entities.Authority;
import com.movies_library.models.entities.User;
import com.movies_library.models.servces.AuthorityServiceModel;
import com.movies_library.models.servces.UserServiceModel;
import com.movies_library.repository.UserRepository;
import com.movies_library.services.AuthorityService;
import com.movies_library.services.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final ModelMapper modelMapper;
    private final PasswordEncoder passwordEncoder;
    private final AuthorityService authorityService;

    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper,
                           PasswordEncoder passwordEncoder, AuthorityService authorityService) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
        this.passwordEncoder = passwordEncoder;
        this.authorityService = authorityService;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username);

        if (user == null) {
            throw new UsernameNotFoundException("Username: " + username + " not found");
        }

        List<GrantedAuthority> authorities = user.getAuthorities()
                .stream()
                .map(r -> new SimpleGrantedAuthority(r.getName().getAuthority()))
                .collect(Collectors.toList());
        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(),
                authorities);
    }

    @Override
    public UserServiceModel register(UserServiceModel user) {
        User userEntity = this.modelMapper.map(user, User.class);

        userEntity.setPassword(passwordEncoder.encode(user.getPassword()));
        this.userRepository.save(userEntity);
        List<Authority> authorities = new ArrayList<>();
        AuthorityServiceModel authorityServiceModel = this.authorityService
                .getAuthorityByName(new SimpleGrantedAuthority("ROLE_USER"));
        authorities.add(this.modelMapper.map(authorityServiceModel, Authority.class));
        userEntity.setAuthorities(authorities);

        this.userRepository.flush();

        return this.modelMapper.map(userEntity, UserServiceModel.class);
    }

    @Override
    public UserServiceModel findByUsername(String username) {
        return this.modelMapper.map(userRepository.findByUsername(username), UserServiceModel.class);
    }

    @Override
    public UserServiceModel findByEmail(String email) {
        return this.modelMapper.map(userRepository.findByEmail(email), UserServiceModel.class);
    }

    @Override
    public List<User> findAll() {
        return this.userRepository.findAll();
    }

//    @Override
//    public boolean usernameExist(String username) {
//        //return this.userRepository.findByUsername(username).isPresent();
//        return null;
//    }
}
