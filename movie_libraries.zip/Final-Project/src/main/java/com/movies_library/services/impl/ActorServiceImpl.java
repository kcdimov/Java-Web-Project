package com.movies_library.services.impl;

import com.movies_library.models.entities.Actor;
import com.movies_library.models.servces.ActorServiceModel;
import com.movies_library.repository.ActorRepository;
import com.movies_library.services.ActorService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ActorServiceImpl implements ActorService {

    private final ActorRepository actorRepository;
    private final ModelMapper modelMapper;

    public ActorServiceImpl(ActorRepository actorRepository, ModelMapper modelMapper) {
        this.actorRepository = actorRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public ActorServiceModel findActorsByNames(String firstName, String lastName) {
        return this.modelMapper.map(actorRepository.findByFirstNameAndLastName(firstName, lastName),
                ActorServiceModel.class);
    }

    @Override
    public ActorServiceModel findById(Long id) {
        Actor actor = this.actorRepository.findById(id).orElse(null);

        if (actor != null) {
            return this.modelMapper.map(actor, ActorServiceModel.class);
        } else {
            //TODO try to replace with message
            return null;
        }

    }

    @Override
    public ActorServiceModel addActor(ActorServiceModel map) {
        this.actorRepository.saveAndFlush(modelMapper.map(map, Actor.class));
        return map;
    }

    @Override
    public List<String> getAllActorsNames() {
        return this.actorRepository.findAllActors();
    }

    @Override
    public List<Actor> getAllActors() {
        return this.actorRepository.findAll();
    }
}
