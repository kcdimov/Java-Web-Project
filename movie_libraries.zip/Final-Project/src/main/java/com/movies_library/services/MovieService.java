package com.movies_library.services;

import com.movies_library.models.bindings.MovieAddBM;
import com.movies_library.models.entities.Movie;
import com.movies_library.models.servces.MovieServiceModel;

import javax.validation.Valid;
import java.util.List;

public interface MovieService {

    MovieServiceModel addMovie(MovieServiceModel map, @Valid MovieAddBM movieAddBM,
                               String currentPrincipalName);
    Movie findMovieByTitle(String movieTitle);

    List<String> getAllTitleOfMovies();

    List<Movie> getAllMovies();

    MovieServiceModel findById(Long id);

    List<Movie> getAllMoviesByGenre(String genre);

    List<Movie> getAllMoviesByUser(String username);
}
