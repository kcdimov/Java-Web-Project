package com.movies_library.services.impl;

import com.movies_library.models.bindings.MovieAddBM;
import com.movies_library.models.entities.Genre;
import com.movies_library.models.entities.Movie;
import com.movies_library.models.entities.User;
import com.movies_library.models.servces.ActorServiceModel;
import com.movies_library.models.servces.DirectorServiceModel;
import com.movies_library.models.servces.MovieServiceModel;
import com.movies_library.models.servces.UserServiceModel;
import com.movies_library.repository.MovieRepository;
import com.movies_library.services.ActorService;
import com.movies_library.services.DirectorService;
import com.movies_library.services.MovieService;
import com.movies_library.services.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Service
public class MovieServiceImpl implements MovieService {
    private final MovieRepository movieRepository;
    private final ModelMapper modelMapper;
    private final ActorService actorService;
    private final UserService userService;
    private final DirectorService directorService;

    public MovieServiceImpl(MovieRepository movieRepository, ModelMapper modelMapper, ActorService actorService, UserService userService, DirectorService directorService) {
        this.movieRepository = movieRepository;
        this.modelMapper = modelMapper;
        this.actorService = actorService;
        this.userService = userService;
        this.directorService = directorService;
    }

    @Override
    public MovieServiceModel addMovie(MovieServiceModel map, @Valid MovieAddBM movieAddBM, String currentPrincipalName) {
        List<Genre> genres = new ArrayList<>();

        genres.add(this.modelMapper.map(movieAddBM.getGenre(), Genre.class));
        genres.add(this.modelMapper.map(movieAddBM.getSubgenre(), Genre.class));

        map.setGenres(genres);

        List<ActorServiceModel> actors = new ArrayList<>();
        actors.add(this.actorService.findActorsByNames(movieAddBM.getActorInLeadingRoleFirstName(),
                movieAddBM.getActorInLeadingRoleLastName()));
        actors.add(this.actorService.findActorsByNames(movieAddBM.getActorInSupportingRoleFirstName(),
                movieAddBM.getActorInSupportingRoleLastName()));

        map.setActors(actors);

        List<UserServiceModel> usersList = new ArrayList<>();
        usersList.add(userService.findByUsername(currentPrincipalName));
        map.setUsers(usersList);

        DirectorServiceModel director = directorService.findDirectorsByNames(movieAddBM.getDirectorFirstName(),
                movieAddBM.getDirectorLastName());
        map.setDirector(director);

        this.movieRepository.saveAndFlush(this.modelMapper.map(map, Movie.class));
        return map;
    }

    @Override
    public Movie findMovieByTitle(String movieTitle) {
        return this.movieRepository.findByTitle(movieTitle);
    }

    @Override
    public List<String> getAllTitleOfMovies() {
        return this.movieRepository.findAllTitles();
    }

    @Override
    public List<Movie> getAllMovies() {
        return this.movieRepository.findAll();
    }

    @Override
    public MovieServiceModel findById(Long id) {
        Movie movie = this.movieRepository.findById(id).orElse(null);

        if(movie != null) {
            return this.modelMapper.map(movie, MovieServiceModel.class);
        } else {
            return null;
        }
    }

    @Override
    public List<Movie> getAllMoviesByGenre(String genre) {
        return this.movieRepository.findAllByGenre(Genre.valueOf(genre));
    }

    @Override
    public List<Movie> getAllMoviesByUser(String username) {
        User user = this.modelMapper.map(this.userService.findByUsername(username), User.class);
        return this.movieRepository.findMoviesByUser(user);

    }

}
