package com.movies_library.services.impl;

import com.movies_library.models.entities.Actor;
import com.movies_library.models.entities.Movie;
import com.movies_library.models.entities.Picture;
import com.movies_library.models.entities.User;
import com.movies_library.models.servces.PictureServiceModel;
import com.movies_library.repository.PictureRepository;
import com.movies_library.services.ActorService;
import com.movies_library.services.MovieService;
import com.movies_library.services.PictureService;
import com.movies_library.services.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;
import java.util.Random;

@Service
public class PictureServiceImpl implements PictureService {

    private final PictureRepository pictureRepository;
    private final ModelMapper modelMapper;
    private final ActorService actorService;
    private final MovieService movieService;
    private final UserService userService;
    private final Random random;

    public PictureServiceImpl(PictureRepository pictureRepository, ModelMapper modelMapper,
                              ActorService actorService, MovieService movieService, UserService userService, Random random) {
        this.pictureRepository = pictureRepository;
        this.modelMapper = modelMapper;
        this.actorService = actorService;
        this.movieService = movieService;
        this.userService = userService;
        this.random = random;
    }


    @Override
    public PictureServiceModel addPicture(PictureServiceModel pictureServiceModel, String actorFirstName,
                                          String actorLastName,
                                          String movie) {
        Picture picture = this.modelMapper.map(pictureServiceModel, Picture.class);

        try {
            Movie titleOvMovie = this.movieService.findMovieByTitle(movie);
            picture.setMovie(titleOvMovie);
        } catch (Exception ex) {
            //throw new IllegalArgumentException(ex.getMessage("Title of movie doesn't exist"));
        }

        try {
            Actor nameOfActor = this.modelMapper.map(this.actorService.findActorsByNames(actorFirstName, actorLastName),
                    Actor.class);
            picture.setActor(nameOfActor);
        } catch (Exception ex) {

        }

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();

        picture.setUser(this.modelMapper.map(this.userService.findByUsername(currentPrincipalName),
                User.class));

        this.pictureRepository.save(picture);

        this.pictureRepository.flush();

        return pictureServiceModel;
    }

    @Override
    public List<Picture> findPictureByActorId(Long id) {
        return this.pictureRepository.findAllByActor_Id(id);
    }

    @Override
    public List<Picture> findPictureByMovieId(Long id) {
        return this.pictureRepository.findAllByMovie_Id(id);
    }

    @Override
    public String getRandomActorPicture(Long id) throws IOException {
        List<Picture> pictureList = findPictureByActorId(id);

        if (pictureList.size() != 0) {
            int n = this.random.nextInt(pictureList.size())+1;
            int count = 1;
            for (Picture picture : pictureList) {
                if (count == n) {
                    return picture.getUrl();
                }
                count++;
            }
        }

        return "/images/movie_random.jpg";
    }

    @Override
    public String getRandomPictureOfMovie(Long id) {
        List<Picture> pictureList  = findPictureByMovieId(id);

        if (pictureList.size() == 0) {
            int n = this.random.nextInt(pictureList.size()) + 1;
            int count = 1;

            for (Picture picture : pictureList) {
                if (count == n) {
                    return picture.getUrl();
                }
                count++;
            }
        }

        return "/images/movie_random.jpg";
    }
}
