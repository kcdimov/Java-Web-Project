package com.movies_library.services;

import com.movies_library.models.servces.AuthorityServiceModel;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

public interface AuthorityService {
  AuthorityServiceModel getAuthorityByName(SimpleGrantedAuthority name);
}