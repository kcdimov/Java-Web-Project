package com.movies_library.services.impl;

import com.movies_library.models.entities.Movie;
import com.movies_library.models.entities.User;
import com.movies_library.services.EmailService;
import com.movies_library.services.MovieService;
import com.movies_library.services.UserService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Random;

@Component
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender emailSender;
    private final Random random;
    private final MovieService movieService;
    private final UserService userService;

    public EmailServiceImpl(@Qualifier("getJavaMailSender") JavaMailSender emailSender, Random random, MovieService movieService, UserService userService) {
        this.emailSender = emailSender;
        this.random = random;
        this.movieService = movieService;
        this.userService = userService;
    }


    @Override
    public void sendMessage() {
        if (this.movieService.getAllMovies().size() != 0) {
            String movieTitle = "";
            Long movieId = Long.valueOf(0);


            int n = this.random.nextInt(this.movieService.getAllMovies().size()) + 1;
            int count = 1;

            for (Movie movie : this.movieService.getAllMovies()) {
                if (count == n) {
                    movieTitle = movie.getTitle();
                    movieId = movie.getId();
                }
                count++;
            }

            List<User> users = this.userService.findAll();
            count = 0;
            String[] to = new String[users.size()];

            for (User user : users) {
                to[count] = user.getEmail();
                count++;
            }

            String subject = "Today's movie released - " + movieTitle;
            String text = "You can check release movie today - " + movieTitle
                    + "!" + System.lineSeparator() + "If you need from more information check the following link: " +
                    "http://localhost:8080/movies/movies-details/" +
                    movieId;

            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom("movie.library.ko@gmail.com");
            message.setTo(to);
            message.setSubject(subject);
            message.setText(text);
            emailSender.send(message);
        }
        //Java mail sender is take from https://www.fatalerrors.org/a/mail-sending-javamailsender.html
    }
}
