package com.movies_library.services.impl;

import com.movies_library.models.entities.Director;
import com.movies_library.models.servces.DirectorServiceModel;
import com.movies_library.repository.DirectorRepository;
import com.movies_library.services.DirectorService;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

@Service
public class DirectorServiceImpl implements DirectorService {

    private final DirectorRepository directorRepository;
    private final ModelMapper modelMapper;

    public DirectorServiceImpl(DirectorRepository directorRepository, ModelMapper modelMapper) {
        this.directorRepository = directorRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public DirectorServiceModel findDirectorsByNames(String firstName, String lastName) {
        return this.modelMapper.map(this.directorRepository.findDirectorByFirstNameAndLastName(firstName, lastName),
                DirectorServiceModel.class);
    }

    @Override
    public DirectorServiceModel addDirector(DirectorServiceModel map) {
        this.directorRepository.saveAndFlush(this.modelMapper.map(map, Director.class));
        return map;
    }

}
