package com.movies_library.services;

import com.movies_library.models.entities.Review;
import com.movies_library.models.servces.ReviewServiceModel;

import java.util.List;

public interface ReviewService {
    ReviewServiceModel addReview(ReviewServiceModel reviewServiceModel, String movie);

    List<Review> getAllReviewsByUsername(String username);
}
