package com.movies_library.services.impl;

import com.movies_library.models.servces.AuthorityServiceModel;
import com.movies_library.repository.AuthorityRepository;
import com.movies_library.services.AuthorityService;
import org.modelmapper.ModelMapper;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
@Transactional
public class AuthorityServiceImpl implements AuthorityService {

    private final AuthorityRepository authorityRepository;
    private final ModelMapper modelMapper;

    public AuthorityServiceImpl(AuthorityRepository authorityRepository, ModelMapper modelMapper) {
        this.authorityRepository = authorityRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public AuthorityServiceModel getAuthorityByName(SimpleGrantedAuthority name) {

        return this.modelMapper.map(authorityRepository.getByName(name), AuthorityServiceModel.class);
    }
}
