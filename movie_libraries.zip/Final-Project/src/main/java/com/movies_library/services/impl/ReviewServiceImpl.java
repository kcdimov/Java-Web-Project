package com.movies_library.services.impl;

import com.movies_library.models.entities.Movie;
import com.movies_library.models.entities.Review;
import com.movies_library.models.entities.User;
import com.movies_library.models.servces.ReviewServiceModel;
import com.movies_library.repository.ReviewRepository;
import com.movies_library.services.MovieService;
import com.movies_library.services.ReviewService;
import com.movies_library.services.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository reviewRepository;
    private final ModelMapper modelMapper;
    private final UserService userService;
    private final MovieService movieService;

    @Autowired
    public ReviewServiceImpl(ReviewRepository reviewRepository, ModelMapper modelMapper,
                             UserService userService, MovieService movieService) {
        this.reviewRepository = reviewRepository;
        this.modelMapper = modelMapper;
        this.userService = userService;
        this.movieService = movieService;
    }

    @Override
    public ReviewServiceModel addReview(ReviewServiceModel reviewServiceModel, String movie) {
        Movie titleOfMovie = this.movieService.findMovieByTitle(movie);
        Review review = this.modelMapper.map(reviewServiceModel, Review.class);

        this.reviewRepository.save(review);
        review.setMovie(titleOfMovie);

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipal = authentication.getName();

        review.setUser(this.modelMapper.map(this.userService.findByUsername(currentPrincipal), User.class));

        this.reviewRepository.flush();

        return reviewServiceModel;
    }

    @Override
    public List<Review> getAllReviewsByUsername(String username) {
        User user = modelMapper.map(this.userService.findByUsername(username), User.class);

        return this.reviewRepository.findAllMovieByUser(user);
    }
}
