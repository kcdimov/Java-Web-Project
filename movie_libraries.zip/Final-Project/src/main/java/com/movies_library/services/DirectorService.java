package com.movies_library.services;

import com.movies_library.models.servces.DirectorServiceModel;

public interface DirectorService {

    DirectorServiceModel findDirectorsByNames(String firstName, String lastName);

    DirectorServiceModel addDirector(DirectorServiceModel map);
}
