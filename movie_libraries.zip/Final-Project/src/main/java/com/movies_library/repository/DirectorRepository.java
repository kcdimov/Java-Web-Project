package com.movies_library.repository;

import com.movies_library.models.entities.Director;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DirectorRepository extends JpaRepository<Director, Long> {
    Director findDirectorByFirstNameAndLastName(String firstName, String lastName);


}
