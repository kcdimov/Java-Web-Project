package com.movies_library.repository;

import com.movies_library.models.entities.Genre;
import com.movies_library.models.entities.Movie;
import com.movies_library.models.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Long> {

    Movie findByTitle(String title);

    //List<Movie> findAllByTitle();

    @Query("SELECT m.title FROM Movie as m")
    List<String> findAllTitles();

    //List<Movie> findMovieByUsers();

    @Query("SELECT m FROM Movie as m WHERE ?1 MEMBER OF m.users")
    List<Movie> findMoviesByUser(User user);

   // List<Movie> findAllByGenres();

    @Query("SELECT m FROM Movie as m WHERE ?1 MEMBER OF m.genres")
    List<Movie> findAllByGenre(Genre genre);

}
