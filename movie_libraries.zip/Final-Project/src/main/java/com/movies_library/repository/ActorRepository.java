package com.movies_library.repository;

import com.movies_library.models.entities.Actor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ActorRepository extends JpaRepository<Actor, Long> {
    Actor findByFirstNameAndLastName(String firstName, String lastName);

    @Query("SELECT a.firstName, a.lastName FROM Actor as a")
    List<String> findAllActors();
}
