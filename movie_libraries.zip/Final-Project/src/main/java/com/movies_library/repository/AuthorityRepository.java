package com.movies_library.repository;

import com.movies_library.models.entities.Authority;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Repository;

@Repository
public interface AuthorityRepository extends JpaRepository<Authority, Long> {
    Authority getByName(SimpleGrantedAuthority name);
}
