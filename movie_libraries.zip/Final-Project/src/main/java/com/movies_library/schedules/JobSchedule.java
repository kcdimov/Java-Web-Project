package com.movies_library.schedules;

import com.movies_library.services.EmailService;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
public class JobSchedule {

    private static final Logger log = LoggerFactory.getLogger(JobSchedule.class);
    private final EmailService emailService;

    public JobSchedule(EmailService emailService) {
        this.emailService = emailService;
    }

//    @Scheduled(fixedRate = 30000)
//    public void logCurrentTime() {
//        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
//        LocalDateTime now = LocalDateTime.now();
//        log.info("The time is now {}", dtf.format(now));
//    }
/*
    @Scheduled(fixedRate = 86400000)
    public void sendSimpleMessage() {
        emailService.sendMessage();

    }*/
}
