package bg.softuni.movies.models.enums;


public enum Genre {
    ANIMATION, ACTION, DRAMA, COMEDY, FAMILY, ROMANCE, MUSICAL,
    ADVENTURE, FANTASY, SCI_FI, CRIME, THRILLER, MYSTERY, HISTORY, WESTERN;
}
