package bg.softuni.movies.models.service;

import bg.softuni.movies.models.entity.Movie;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import java.util.List;

public class ActorServiceModel extends BaseEntityServiceModel {
//    private String firstName;
//    private String lastName;
    private String actorName;
    private List<Movie> movies;
    private List<PictureServiceModel> pictures;


    public ActorServiceModel() {
    }

    @NotBlank
    @Length(min = 3)
    public String getActorName() {
        return actorName;
    }

    public void setActorName(String actorName) {
        this.actorName = actorName;
    }

//    @NotBlank
//    @Length(min = 3)
//    public String getFirstName() {
//        return firstName;
//    }
//
//    public void setFirstName(String firstName) {
//        this.firstName = firstName;
//    }
//
//    @NotBlank
//    @Length(min = 3)
//    public String getLastName() {
//        return lastName;
//    }
//
//    public void setLastName(String lastName) {
//        this.lastName = lastName;
//    }

    public List<Movie> getMovies() {
        return movies;
    }

    public void setMovies(List<Movie> movies) {
        this.movies = movies;
    }

    public List<PictureServiceModel> getPictures() {
        return pictures;
    }

    public void setPictures(List<PictureServiceModel> pictures) {
        this.pictures = pictures;
    }
}
