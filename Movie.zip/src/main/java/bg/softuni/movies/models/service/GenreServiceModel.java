package bg.softuni.movies.models.service;

public enum GenreServiceModel {
    ANIMATION, ACTION, DRAMA, COMEDY, FAMILY, ROMANCE, MUSICAL,
    ADVENTURE, FANTASY, SCI_FI, CRIME, THRILLER, MYSTERY, HISTORY, WESTERN;
}
