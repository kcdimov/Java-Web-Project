package bg.softuni.movies.models.entity;



import bg.softuni.movies.models.enums.Genre;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "movies")
public class Movie extends BaseEntity {

    private String plot; //description
    private String title;
  //  private Director director;
    private List<Actor> starring;
  //  private Music composer;
    private List<Picture> pictures;
    //TODO change to one user
    private List<UserEntity> userEntities;
    private List<Review> reviews;
    private List<Genre> genres;

    public Movie() {
    }

    @Column(columnDefinition = "TEXT")
    public String getPlot() {
        return plot;
    }

    public void setPlot(String plot) {
        this.plot = plot;
    }

    @Column(unique = true)
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

//    @ManyToOne
//    public Director getDirectors() {
//        return director;
//    }
//
//    public void setDirectors(Director director) {
//        this.director = director;
//    }

    @ManyToMany
    public List<Actor> getStarring() {
        return starring;
    }

    public void setStarring(List<Actor> starring) {
        this.starring = starring;
    }

//    @OneToOne
//    public Music getComposers() {
//        return composer;
//    }
//
//    public void setComposers(Music composers) {
//        this.composer = composer;
//    }

    @OneToMany
    public List<Picture> getPictures() {
        return pictures;
    }

    public void setPictures(List<Picture> pictures) {
        this.pictures = pictures;
    }

    @ManyToMany
    public List<UserEntity> getUsers() {
        return userEntities;
    }

    public void setUsers(List<UserEntity> userEntities) {
        this.userEntities = userEntities;
    }

    @ManyToMany
    public List<Review> getReviews() {
        return reviews;
    }

    public void setReviews(List<Review> reviews) {
        this.reviews = reviews;
    }

    @ElementCollection(fetch = FetchType.LAZY)
    @Enumerated(EnumType.STRING)
    public List<Genre> getGenres() {
        return genres;
    }

    public void setGenres(List<Genre> genres) {
        this.genres = genres;
    }
}
