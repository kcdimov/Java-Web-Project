package bg.softuni.movies.services;

import bg.softuni.movies.models.bindings.MovieAddBM;
import bg.softuni.movies.models.entity.Movie;
import bg.softuni.movies.models.entity.UserEntity;
import bg.softuni.movies.models.enums.Genre;
import bg.softuni.movies.models.service.ActorServiceModel;
import bg.softuni.movies.models.service.MovieServiceModel;
import bg.softuni.movies.models.service.UserServiceModel;
import bg.softuni.movies.repository.MovieRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

@Service
public class MovieService {

    private final MovieRepository movieRepository;
    private final ModelMapper modelMapper;
    private final ActorService actorService;
    private final UserService userService;

    public MovieService(MovieRepository movieRepository, ModelMapper modelMapper, ActorService actorService, UserService userService) {
        this.movieRepository = movieRepository;
        this.modelMapper = modelMapper;
        this.actorService = actorService;
        this.userService = userService;
    }

    public MovieServiceModel addMovie(MovieServiceModel map, @Valid MovieAddBM movieAddBM, String currentPrincipalName) {
        List<Genre> genres = new ArrayList<>();

        genres.add(this.modelMapper.map(movieAddBM.getGenre(), Genre.class));
        genres.add(this.modelMapper.map(movieAddBM.getSubgenre(), Genre.class));

        map.setGenres(genres);

        List<ActorServiceModel> actors = new ArrayList<>();
        actors.add(this.actorService.findActorsByNames(movieAddBM.getActorInLeadingRole()));
        actors.add(this.actorService.findActorsByNames(movieAddBM.getActorInSupportingRole()));

        map.setActors(actors);

        List<UserServiceModel> usersList = new ArrayList<>();
        usersList.add(userService.findByUsername(currentPrincipalName));
        map.setUsers(usersList);

//        DirectorServiceModel director = directorService.findDirectorsByNames(movieAddBM.getDirectorFirstName(),
//                movieAddBM.getDirectorLastName());
//        map.setDirector(director);

        this.movieRepository.saveAndFlush(this.modelMapper.map(map, Movie.class));
        return map;
    }

    public Movie findMovieByTitle(String movieTitle) {
        return this.movieRepository.findByTitle(movieTitle);
    }

    public List<String> getAllTitleOfMovies() {
        return this.movieRepository.findAllTitles();
    }

    public List<Movie> getAllMovies() {
        return this.movieRepository.findAll();
    }

    public MovieServiceModel findById(Long id) {
        Movie movie = this.movieRepository.findById(id).orElse(null);

        if(movie != null) {
            return this.modelMapper.map(movie, MovieServiceModel.class);
        } else {
            return null;
        }
    }

    public List<Movie> getAllMoviesByGenre(String genre) {
        return this.movieRepository.findAllByGenre(Genre.valueOf(genre));
    }

    public List<Movie> getAllMoviesByUser(String username) {
        UserEntity userEntity = this.modelMapper.map(this.userService.findByUsername(username), UserEntity.class);
        return this.movieRepository.findMoviesByUser(userEntity);

    }

}
