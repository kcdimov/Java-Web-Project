package bg.softuni.movies.services;

import bg.softuni.movies.models.service.ActorServiceModel;
import org.springframework.stereotype.Service;

@Service
public class ActorService {

    public ActorServiceModel findActorsByNames(String actorInLeadingRole) {
        //TODO find actor by name
        return null;
    }

    public Object getAllActors() {
        //TODO find all actors
        return null;
    }
}
