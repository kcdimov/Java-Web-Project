package bg.softuni.movies.services;

import bg.softuni.movies.models.entity.Review;
import bg.softuni.movies.models.entity.UserEntity;
import bg.softuni.movies.repository.ReviewRepository;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final ModelMapper modelMapper;
    private final UserService userService;
    private final MovieService movieService;

    public ReviewService(ReviewRepository reviewRepository, ModelMapper modelMapper,
                         UserService userService, MovieService movieService) {
        this.reviewRepository = reviewRepository;
        this.modelMapper = modelMapper;
        this.userService = userService;
        this.movieService = movieService;
    }

    public List<Review> getAllReviewsByUsername(String username) {
        UserEntity userEntity = modelMapper.map(this.userService.findByUsername(username), UserEntity.class);

        return this.reviewRepository.findAllMovieByUser(userEntity);
    }
}
